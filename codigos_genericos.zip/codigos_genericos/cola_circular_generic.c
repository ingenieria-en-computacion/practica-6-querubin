#include "cola_circular_generic.h"
#include <stdio.h>

#define IMPLEMENT_COLA_CIRCULAR(TYPE)\
    ColaCircular_##TYPE* cola_circular_##TYPE##_create(size_t capacity) {\
        ColaCircular_##TYPE* cola = malloc(sizeof(ColaCircular_##TYPE));\
        cola->arr = malloc(sizeof(TYPE) * capacity);\
        cola->front = 0;\
        cola->rear = 0;\
        cola->capacity = capacity;\
        cola->size = 0;\
        return cola;\
    }\
    \
    void cola_circular_##TYPE##_destroy(ColaCircular_##TYPE* cola) {\
        free(cola->arr);\
        free(cola);\
    }\
    \
    bool cola_circular_##TYPE##_is_empty(const ColaCircular_##TYPE* cola) {\
        return;
