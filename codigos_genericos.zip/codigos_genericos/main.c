#define IMPLEMENT_BICOLA_
#define IMPLEMENT_COLA_CIRCULAR_
#include "bicola_generic.h"
#include "cola_circular_generic.h"
#include <stdio.h>

void print_int(int value) {
    printf("%d", value);
}

void print_char(char value) {
    printf("%c", value);
}

int main() {
    
    printf("Bicola Genérica con `int`:\n");
    Bicola_int* bicola_int = bicola_int_create(5);
    bicola_int_insert_rear(bicola_int, 10);
    bicola_int_insert_rear(bicola_int, 20);
    bicola_int_insert_front(bicola_int, 5);
    bicola_int_print(bicola_int, print_int);
    
    int value;
    bicola_int_remove_front(bicola_int, &value);
    printf("Valor removido de frente: %d\n", value);
    bicola_int_remove_rear(bicola_int, &value);
    printf("Valor removido de atrás: %d\n", value);
    bicola_int_print(bicola_int, print_int);
    
    bicola_int_destroy(bicola_int);

  
    printf("\nCola Circular Genérica con `int`:\n");
    ColaCircular_int* cola_int = cola_circular_int_create(5);
    cola_circular_int_enqueue(cola_int, 10);
    cola_circular_int_enqueue(cola_int, 20);
    cola_circular_int_enqueue(cola_int, 30);
    cola_circular_int_print(cola_int, print_int);
    
    cola_circular_int_dequeue(cola_int, &value);
    printf("Valor removido: %d\n", value);
    cola_circular_int_print(cola_int, print_int);
    
    cola_circular_int_destroy(cola_int);

   
    printf("\nBicola Genérica con `char`:\n");
    Bicola_char* bicola_char = bicola_char_create(5);
    bicola_char_insert_rear(bicola_char, 'a');
    bicola_char_insert_rear(bicola_char, 'b');
    bicola_char_insert_front(bicola_char, 'z');
    bicola_char_print(bicola_char, print_char);
    
    char char_value;
    bicola_char_remove_front(bicola_char, &char_value);
    printf("Valor removido de frente: %c\n", char_value);
    bicola_char_remove_rear(bicola_char, &char_value);
    printf("Valor removido de atrás: %c\n", char_value);
    bicola_char_print(bicola_char, print_char);
    
    bicola_char_destroy(bicola_char);

   
    printf("\nCola Circular Genérica con `char`:\n");
    ColaCircular_char* cola_char = cola_circular_char_create(5);
    cola_circular_char_enqueue(cola_char, 'a');
    cola_circular_char_enqueue(cola_char, 'b');
    cola_circular_char_enqueue(cola_char, 'c');
    cola_circular_char_print(cola_char, print_char);
    
    cola_circular_char_dequeue(cola_char, &char_value);
    printf("Valor removido: %c\n", char_value);
    cola_circular_char_print(cola_char, print_char);
    
    cola_circular_char_destroy(cola_char);

    return 0;
}
