#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#define DECLARE_BICOLA(TYPE)\
    typedef struct {\
        TYPE* arr;\
        size_t front;\
        size_t rear;\
        size_t capacity;\
        size_t size;\
    } Bicola_##TYPE;\
    Bicola_##TYPE* bicola_##TYPE##_create(size_t capacity);\
    void bicola_##TYPE##_destroy(Bicola_##TYPE* bicola);\
    bool bicola_##TYPE##_is_empty(const Bicola_##TYPE* bicola);\
    bool bicola_##TYPE##_is_full(const Bicola_##TYPE* bicola);\
    bool bicola_##TYPE##_insert_front(Bicola_##TYPE* bicola, TYPE value);\
    bool bicola_##TYPE##_insert_rear(Bicola_##TYPE* bicola, TYPE value);\
    bool bicola_##TYPE##_remove_front(Bicola_##TYPE* bicola, TYPE* out);\
    bool bicola_##TYPE##_remove_rear(Bicola_##TYPE* bicola, TYPE* out);\
    void bicola_##TYPE##_print(const Bicola_##TYPE* bicola, void (*print_fn)(TYPE));

