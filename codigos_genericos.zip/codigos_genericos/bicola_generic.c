#include "bicola_generic.h"
#include <stdio.h>

#define IMPLEMENT_BICOLA(TYPE)\
    Bicola_##TYPE* bicola_##TYPE##_create(size_t capacity) {\
        Bicola_##TYPE* bicola = malloc(sizeof(Bicola_##TYPE));\
        bicola->arr = malloc(sizeof(TYPE) * capacity);\
        bicola->front = 0;\
        bicola->rear = 0;\
        bicola->capacity = capacity;\
        bicola->size = 0;\
        return bicola;\
    }\
    \
    void bicola_##TYPE##_destroy(Bicola_##TYPE* bicola) {\
        free(bicola->arr);\
        free(bicola);\
    }\
    \
    bool bicola_##TYPE##_is_empty(const Bicola_##TYPE* bicola) {\
        return bicola->size == 0;\
    }\
    \
    bool bicola_##TYPE##_is_full(const Bicola_##TYPE* bicola) {\
        return bicola->size == bicola->capacity;\
    }\
    \
    bool bicola_##TYPE##_insert_front(Bicola_##TYPE* bicola, TYPE value) {\
        if (bicola_##TYPE##_is_full(bicola)) return false;\
        bicola->front = (bicola->front - 1 + bicola->capacity) % bicola->capacity;\
        bicola->arr[bicola->front] = value;\
        bicola->size++;\
        return true;\
    }\
    \
    bool bicola_##TYPE##_insert_rear(Bicola_##TYPE* bicola, TYPE value) {\
        if (bicola_##TYPE##_is_full(bicola)) return false;\
        bicola->arr[bicola->rear] = value;\
        bicola->rear = (bicola->rear + 1) % bicola->capacity;\
        bicola->size++;\
        return true;\
    }\
    \
    bool bicola_##TYPE##_remove_front(Bicola_##TYPE* bicola, TYPE* out) {\
        if (bicola_##TYPE##_is_empty(bicola)) return false;\
        *out = bicola->arr[bicola->front];\
        bicola->front = (bicola->front + 1) % bicola->capacity;\
        bicola->size--;\
        return true;\
    }\
    \
    bool bicola_##TYPE##_remove_rear(Bicola_##TYPE* bicola, TYPE* out) {\
        if (bicola_##TYPE##_is_empty(bicola)) return false;\
        bicola->rear = (bicola->rear - 1 + bicola->capacity) % bicola->capacity;\
        *out = bicola->arr[bicola->rear];\
        bicola->size--;\
        return true;\
    }\
    \
    void bicola_##TYPE##_print(const Bicola_##TYPE* bicola, void (*print_fn)(TYPE)) {\
        size_t i = bicola->front;\
        printf("[");\
        for (size_t count = 0; count < bicola->size; count++) {\
            print_fn(bicola->arr[i]);\
            if (count < bicola->size - 1) {\
                printf(", ");\
            }\
            i = (i + 1) % bicola->capacity;\
        }\
        printf("]\n");\
    }\
