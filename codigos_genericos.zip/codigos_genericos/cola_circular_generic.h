#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#define DECLARE_COLA_CIRCULAR(TYPE)\
    typedef struct {\
        TYPE* arr;\
        size_t front;\
        size_t rear;\
        size_t capacity;\
        size_t size;\
    }ColaCircular_##TYPE;\
    ColaCircular_##TYPE* cola_circular_##TYPE##_create(size_t capacity);\
    void cola_circular_##TYPE##_destroy(ColaCircular_##TYPE* cola);\
    bool cola_circular_##TYPE##_is_empty(const ColaCircular_##TYPE* cola);\
    bool cola_circular_##TYPE##_is_full(const ColaCircular_##TYPE* cola);\
    bool cola_circular_##TYPE##_enqueue(ColaCircular_##TYPE* cola, TYPE value);\
    bool cola_circular_##TYPE##_dequeue(ColaCircular_##TYPE* cola, TYPE* out);\
    void cola_circular_##TYPE##_print(const ColaCircular_##TYPE* cola, void (*print_fn)(TYPE));

