#include "bicola_array.h"
#include "cola_circular_array.h"
#include <stdio.h>

void print_int(int value) {
    printf("%d", value);
}

int main() {
    
    printf("Bicola con arreglos:\n");
    Bicola_int* bicola = bicola_int_create(5);
    bicola_int_insert_rear(bicola, 10);
    bicola_int_insert_rear(bicola, 20);
    bicola_int_insert_front(bicola, 5);
    bicola_int_print(bicola);
    
    int value;
    bicola_int_remove_front(bicola, &value);
    printf("Valor removido de frente: %d\n", value);
    bicola_int_remove_rear(bicola, &value);
    printf("Valor removido de atrás: %d\n", value);
    bicola_int_print(bicola);
    
    bicola_int_destroy(bicola);

    printf("\nCola Circular con arreglos:\n");
    ColaCircular_int* cola = cola_circular_int_create(5);
    cola_circular_int_enqueue(cola, 10);
    cola_circular_int_enqueue(cola, 20);
    cola_circular_int_enqueue(cola, 30);
    cola_circular_int_print(cola);
    
    cola_circular_int_dequeue(cola, &value);
    printf("Valor removido: %d\n", value);
    cola_circular_int_print(cola);
    
    cola_circular_int_destroy(cola);

    return 0;
}
