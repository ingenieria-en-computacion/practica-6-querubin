#include "cola_circular_array.h"
#include <stdio.h>

ColaCircular_int* cola_circular_int_create(size_t capacity) {
    ColaCircular_int* cola = malloc(sizeof(ColaCircular_int));
    cola->arr = malloc(sizeof(int) * capacity);
    cola->front = 0;
    cola->rear = 0;
    cola->capacity = capacity;
    cola->size = 0;
    return cola;
}

void cola_circular_int_destroy(ColaCircular_int* cola) {
    free(cola->arr);
    free(cola);
}

bool cola_circular_int_is_empty(const ColaCircular_int* cola) {
    return cola->size == 0;
}

bool cola_circular_int_is_full(const ColaCircular_int* cola) {
    return cola->size == cola->capacity;
}

bool cola_circular_int_enqueue(ColaCircular_int* cola, int value) {
    if (cola_circular_int_is_full(cola)) return false;
    cola->arr[cola->rear] = value;
    cola->rear = (cola->rear + 1) % cola->capacity;
    cola->size++;
    return true;
}

bool cola_circular_int_dequeue(ColaCircular_int* cola, int* out) {
    if (cola_circular_int_is_empty(cola)) return false;
    *out = cola->arr[cola->front];
    cola->front = (cola->front + 1) % cola->capacity;
    cola->size--;
    return true;
}

void cola_circular_int_print(const ColaCircular_int* cola) {
    size_t i = cola->front;
    printf("[");
    for (size_t count = 0; count < cola->size; count++) {
        printf("%d", cola->arr[i]);
        if (count < cola->size - 1) {
            printf(", ");
        }
        i = (i + 1) % cola->capacity;
    }
    printf("]\n");
}
