#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    int* arr;
    size_t front;
    size_t rear;
    size_t capacity;
    size_t size;
} ColaCircular_int;

ColaCircular_int* cola_circular_int_create(size_t capacity);
void cola_circular_int_destroy(ColaCircular_int* cola);
bool cola_circular_int_is_empty(const ColaCircular_int* cola);
bool cola_circular_int_is_full(const ColaCircular_int* cola);
bool cola_circular_int_enqueue(ColaCircular_int* cola, int value);
bool cola_circular_int_dequeue(ColaCircular_int* cola, int* out);
void cola_circular_int_print(const ColaCircular_int* cola);
