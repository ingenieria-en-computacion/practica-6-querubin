#pragma once
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    int* arr;
    size_t front;
    size_t rear;
    size_t capacity;
    size_t size;
} Bicola_int;

Bicola_int* bicola_int_create(size_t capacity);
void bicola_int_destroy(Bicola_int* bicola);
bool bicola_int_is_empty(const Bicola_int* bicola);
bool bicola_int_is_full(const Bicola_int* bicola);
bool bicola_int_insert_front(Bicola_int* bicola, int value);
bool bicola_int_insert_rear(Bicola_int* bicola, int value);
bool bicola_int_remove_front(Bicola_int* bicola, int* out);
bool bicola_int_remove_rear(Bicola_int* bicola, int* out);
void bicola_int_print(const Bicola_int* bicola);

