#include "bicola_array.h"
#include <stdio.h>

Bicola_int* bicola_int_create(size_t capacity) {
    Bicola_int* bicola = malloc(sizeof(Bicola_int));
    bicola->arr = malloc(sizeof(int) * capacity);
    bicola->front = 0;
    bicola->rear = 0;
    bicola->capacity = capacity;
    bicola->size = 0;
    return bicola;
}

void bicola_int_destroy(Bicola_int* bicola) {
    free(bicola->arr);
    free(bicola);
}

bool bicola_int_is_empty(const Bicola_int* bicola) {
    return bicola->size == 0;
}

bool bicola_int_is_full(const Bicola_int* bicola) {
    return bicola->size == bicola->capacity;
}

bool bicola_int_insert_front(Bicola_int* bicola, int value) {
    if (bicola_int_is_full(bicola)) return false;
    bicola->front = (bicola->front - 1 + bicola->capacity) % bicola->capacity;
    bicola->arr[bicola->front] = value;
    bicola->size++;
    return true;
}

bool bicola_int_insert_rear(Bicola_int* bicola, int value) {
    if (bicola_int_is_full(bicola)) return false;
    bicola->arr[bicola->rear] = value;
    bicola->rear = (bicola->rear + 1) % bicola->capacity;
    bicola->size++;
    return true;
}

bool bicola_int_remove_front(Bicola_int* bicola, int* out) {
    if (bicola_int_is_empty(bicola)) return false;
    *out = bicola->arr[bicola->front];
    bicola->front = (bicola->front + 1) % bicola->capacity;
    bicola->size--;
    return true;
}

bool bicola_int_remove_rear(Bicola_int* bicola, int* out) {
    if (bicola_int_is_empty(bicola)) return false;
    bicola->rear = (bicola->rear - 1 + bicola->capacity) % bicola->capacity;
    *out = bicola->arr[bicola->rear];
    bicola->size--;
    return true;
}

void bicola_int_print(const Bicola_int* bicola) {
    size_t i = bicola->front;
    printf("[");
    for (size_t count = 0; count < bicola->size; count++) {
        printf("%d", bicola->arr[i]);
        if (count < bicola->size - 1) {
            printf(", ");
        }
        i = (i + 1) % bicola->capacity;
    }
    printf("]\n");
}
